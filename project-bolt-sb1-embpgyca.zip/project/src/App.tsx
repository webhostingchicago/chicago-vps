import React from 'react';
import { Server, Shield, Zap, Clock, DollarSign, HeartPulse } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-800">
      {/* Hero Section */}
      <div 
        className="relative min-h-[600px] flex items-center"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=2072")',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-black/60"></div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
              Chicago-Based VPS Hosting
              <span className="text-blue-400"> Built for Performance</span>
            </h1>
            <p className="text-xl text-gray-200 mb-8">
              Lightning-fast servers, 99.9% uptime, and world-class support in the heart of Chicago.
            </p>
            <a 
              href="https://webhostingchicago.duoservers.com/"
              className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 rounded-lg text-lg font-semibold transition-colors inline-block"
            >
              Get Started Now
            </a>
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="container mx-auto px-6 py-20">
        <div className="grid md:grid-cols-3 gap-8">
          <FeatureCard
            icon={<Server className="w-8 h-8 text-blue-400" />}
            title="High-Performance Infrastructure"
            description="Enterprise-grade hardware with NVMe SSDs for blazing-fast performance"
          />
          <FeatureCard
            icon={<Shield className="w-8 h-8 text-blue-400" />}
            title="Advanced Security"
            description="DDoS protection and regular security updates included"
          />
          <FeatureCard
            icon={<Zap className="w-8 h-8 text-blue-400" />}
            title="Instant Deployment"
            description="Get your VPS up and running in under 60 seconds"
          />
          <FeatureCard
            icon={<Clock className="w-8 h-8 text-blue-400" />}
            title="99.9% Uptime"
            description="Guaranteed uptime with redundant infrastructure"
          />
          <FeatureCard
            icon={<DollarSign className="w-8 h-8 text-blue-400" />}
            title="Competitive Pricing"
            description="Flexible plans starting from just $5/month"
          />
          <FeatureCard
            icon={<HeartPulse className="w-8 h-8 text-blue-400" />}
            title="24/7 Support"
            description="Expert technical support available around the clock"
          />
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-slate-900 py-20">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Launch Your VPS?
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Join thousands of satisfied customers who trust our Chicago-based infrastructure for their hosting needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="https://webhostingchicago.duoservers.com/"
              className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 rounded-lg text-lg font-semibold transition-colors inline-block"
            >
              View Plans
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

function FeatureCard({ icon, title, description }) {
  return (
    <div className="bg-slate-800 p-6 rounded-xl hover:bg-slate-700 transition-colors">
      <div className="mb-4">{icon}</div>
      <h3 className="text-xl font-semibold text-white mb-2">{title}</h3>
      <p className="text-gray-300">{description}</p>
    </div>
  );
}

export default App;